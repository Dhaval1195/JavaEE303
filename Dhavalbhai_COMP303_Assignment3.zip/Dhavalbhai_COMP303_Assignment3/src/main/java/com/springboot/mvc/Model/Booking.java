package com.springboot.mvc.Model;

public class Booking {
	

	
	
	 private int bookingId;
	 private int customerId;
	 private int cruiseCode;
	 private String numberOfGuests;
	 private String amountPaid;
	 private String startDate;
	 
	    
	    
	    
	    
		public Booking() {
		
		}





		public Booking(int bookingId, int customerId, int cruiseCode, String numberOfGuests, String amountPaid,
				String startDate) {
			super();
			this.bookingId = bookingId;
			this.customerId = customerId;
			this.cruiseCode = cruiseCode;
			this.numberOfGuests = numberOfGuests;
			this.amountPaid = amountPaid;
			this.startDate = startDate;
		}





		public int getBookingId() {
			return bookingId;
		}





		public void setBookingId(int bookingId) {
			this.bookingId = bookingId;
		}





		public int getCustomerId() {
			return customerId;
		}





		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}





		public int getCruiseCode() {
			return cruiseCode;
		}





		public void setCruiseCode(int cruiseCode) {
			this.cruiseCode = cruiseCode;
		}





		public String getNumberOfGuests() {
			return numberOfGuests;
		}





		public void setNumberOfGuests(String numberOfGuests) {
			this.numberOfGuests = numberOfGuests;
		}





		public String getAmountPaid() {
			return amountPaid;
		}





		public void setAmountPaid(String amountPaid) {
			this.amountPaid = amountPaid;
		}





		public String getStartDate() {
			return startDate;
		}





		public void setStartDate(String startDate) {
			this.startDate = startDate;
		}




	




	    
	    
}
