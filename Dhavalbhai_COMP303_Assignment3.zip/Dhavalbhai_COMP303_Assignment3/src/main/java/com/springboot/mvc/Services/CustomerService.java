package com.springboot.mvc.Services;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.springboot.mvc.Model.Customer;


@Service
public class CustomerService {
    
  
    Map<Integer, Customer> customerMap = new HashMap<>();
    
    //to add new instance
    public void addCustomer(Customer customer) throws Exception {
       
        if (customerMap.containsKey(customer.getCustomerId())) {
            throw new Exception("Customer Id already exists");
        } else {
            customerMap.put(customer.getCustomerId(), customer);
        }
    }
    
    // to get all instances
    public Iterable<Customer> getCustomers() {
        return customerMap.values();
    }
    
  //to get the customer instance from custID
    public Customer getCustomer(int custid) throws Exception {
        if (customerMap.containsKey(custid)) {
            return customerMap.get(custid);
        } else {
            throw new Exception("Customer Id not found");
        }
    }
    
  //to update the customer instance
    public void updateCustomer(Customer customer) throws Exception {
        if (customerMap.containsKey(customer.getCustomerId())) {
            customerMap.put(customer.getCustomerId(), customer);
        } else {
            throw new Exception("Customer Id not found");
        }
    }
    
    //to delete the customer instance
    public void deleteCustomer(int custid) throws Exception {
        if (customerMap.containsKey(custid)) {
            customerMap.remove(custid);
        } else {
            throw new Exception("Customer Id not found");
        }
    }
    
}
