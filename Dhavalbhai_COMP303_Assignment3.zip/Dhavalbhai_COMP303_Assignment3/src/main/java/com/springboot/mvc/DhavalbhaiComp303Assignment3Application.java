package com.springboot.mvc;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.springboot.mvc.Model.Cruise;
import com.springboot.mvc.Model.Customer;
import com.springboot.mvc.Services.CruiseService;
import com.springboot.mvc.Services.CustomerService;

@SpringBootApplication
public class DhavalbhaiComp303Assignment3Application {

	public static void main(String[] args) {
		SpringApplication.run(DhavalbhaiComp303Assignment3Application.class, args);
	}
	
	 @Bean
	    public ApplicationRunner CustomerInitializer(CustomerService customerService) {
	        return args -> {
	        	
	        	
	            // set initial data
	        	customerService.addCustomer(new Customer(1, "Dhaval", "Patel", "735 Don Mills", "Toronto","4379702094","Dhavalgmail.com"));
	        	
	        };
	    }

	 @Bean
	    public ApplicationRunner CruiseInitializer(CruiseService cruiseService) {
	        return args -> {
	        	
	            // set initial data
	        	cruiseService.addCruise(new Cruise(123, "Ciries Of Light", "Amsterdam to Budapest", 4999.0,15));
	        	
	        };
	    }

	 
	 
}
