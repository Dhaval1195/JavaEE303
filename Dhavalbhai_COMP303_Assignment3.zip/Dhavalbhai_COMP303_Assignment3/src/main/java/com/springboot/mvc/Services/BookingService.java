package com.springboot.mvc.Services;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.springboot.mvc.Model.Booking;


@Service
public class BookingService {
    
    
    Map<Integer, Booking> bookingmap = new HashMap<>();
    
    // to add booking instance
    public void addBooking(Booking booking) throws Exception {
        // to check the instance
        if (bookingmap.containsKey(booking.getBookingId())) {
            throw new Exception("Booking code already exists");
        } else {
        	bookingmap.put(booking.getBookingId(), booking);
        }
    }
    
    // to get all booking
    public Iterable<Booking> getBookings() {
        return bookingmap.values();
    }
    
    // to get a booking instance
    public Booking getBooking(int bookingid) throws Exception {
        if (bookingmap.containsKey(bookingid)) {
            return bookingmap.get(bookingid);
        } else {
            throw new Exception("Booking code not found");
        }
    }
    
    // to Update a booking instance
    public void updateBooking(Booking booking) throws Exception {
        if (bookingmap.containsKey(booking.getBookingId())) {
        	bookingmap.put(booking.getBookingId(), booking);
        } else {
            throw new Exception("Booking code not found");
        }
    }
    
    // to delete a booking instance
    public void deleteBooking(int bookingid) throws Exception {
        if (bookingmap.containsKey(bookingid)) {
        	bookingmap.remove(bookingid);
        } else {
            throw new Exception("Booking code not found");
        }
    }
    
}
