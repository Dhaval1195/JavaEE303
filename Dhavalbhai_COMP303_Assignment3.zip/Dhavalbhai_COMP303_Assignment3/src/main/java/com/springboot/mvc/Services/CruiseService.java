package com.springboot.mvc.Services;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.springboot.mvc.Model.Cruise;


@Service
public class CruiseService {
    
  
    Map<Integer, Cruise> cruiseMap = new HashMap<>();
    
    // to add Cruise instance
    public void addCruise(Cruise cruise) throws Exception {
        // to check the instance
        if (cruiseMap.containsKey(cruise.getCruiseCode())) {
            throw new Exception("Cruise code already exists");
        } else {
            cruiseMap.put(cruise.getCruiseCode(), cruise);
        }
    }
    
    // to get all instance
    public Iterable<Cruise> getCruises() {
        return cruiseMap.values();
    }
    
    // to get the instance
    public Cruise getCruise(int cruisecode) throws Exception {
        if (cruiseMap.containsKey(cruisecode)) {
            return cruiseMap.get(cruisecode);
        } else {
            throw new Exception("Cruise code not found");
        }
    }
    
    // to update the instance
    public void updateCruise(Cruise cruise) throws Exception {
        if (cruiseMap.containsKey(cruise.getCruiseCode())) {
            cruiseMap.put(cruise.getCruiseCode(), cruise);
        } else {
            throw new Exception("Cruise code not found");
        }
    }
    
    // to delete the instance
    public void deleteCruise(int cruisecode) throws Exception {
        if (cruiseMap.containsKey(cruisecode)) {
            cruiseMap.remove(cruisecode);
        } else {
            throw new Exception("Cruise code not found");
        }
    }
    
}
