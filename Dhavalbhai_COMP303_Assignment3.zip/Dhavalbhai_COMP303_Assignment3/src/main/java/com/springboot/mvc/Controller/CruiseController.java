package com.springboot.mvc.Controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.mvc.Model.Cruise;
import com.springboot.mvc.Services.CruiseService;

/* Used template and refer to code from
read://https_www.baeldung.com/?url=https%3A%2F%2Fwww.baeldung.com%2Fspring-boot-crud-thymeleaf
*/

@RestController
public class CruiseController {

	@Autowired
    CruiseService cruiseService;
	
	
	 @GetMapping(value = "/cruises")
	    ModelAndView getCruises() throws Exception {
	        ModelAndView mv = new ModelAndView();
	        mv.setViewName("cruises");
	        mv.addObject("cruiseList", cruiseService.getCruises());
	        mv.addObject("title", "Cruise List"); 
	        return mv;
	    }
	
	 
	   @PostMapping(value = "/cruise/add", consumes = "application/x-www-form-urlencoded")
	    @ResponseStatus(value = HttpStatus.OK)
	    void addCruise(Cruise cruise, HttpServletResponse httpResponse) throws Exception {
	        cruiseService.addCruise(cruise);
	        httpResponse.sendRedirect("/cruises");
	    }
	   
	   
	   // GET - find by CruiseCode
	    @GetMapping(value = "/cruise/edit/{cruiseCode}")
	    ModelAndView getCruise(@PathVariable("cruiseCode") int cruiseCode) throws Exception {
	        ModelAndView mv = new ModelAndView();
	        mv.setViewName("editCruise");
	        mv.addObject("cruise", cruiseService.getCruise(cruiseCode));
	        
	        return mv;
	    }
	    
	    @PostMapping(value = "/cruise/edit/{cruiseCode}", consumes = "application/x-www-form-urlencoded")
	    @ResponseStatus(value = HttpStatus.OK)
	    void updateCruise(Cruise cruise, HttpServletResponse httpResponse) throws Exception {
	        cruiseService.updateCruise(cruise);
	        httpResponse.sendRedirect("/cruises");
	    }
	    
	 // DELETE - delete a cruise 
	    @GetMapping(value = "/cruise/delete/{cruiseCode}")
	    @ResponseStatus(value = HttpStatus.OK)
	    void deleteCruise(@PathVariable("cruiseCode") int cruiseCode, HttpServletResponse httpResponse) throws Exception {
	        cruiseService.deleteCruise(cruiseCode);
	        
	        // redirect to cruise list
	        httpResponse.sendRedirect("/cruises");
	    }
}
