package com.springboot.mvc.Controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.mvc.Model.Customer;
import com.springboot.mvc.Services.CustomerService;

@RestController
public class CustomerController {

	/* Used template and refer to code from
	read://https_www.baeldung.com/?url=https%3A%2F%2Fwww.baeldung.com%2Fspring-boot-crud-thymeleaf
	*/
	
	@Autowired
    CustomerService customerService;
	
	
	 @GetMapping(value = "/customers")
	    ModelAndView getCustomers() throws Exception {
	        ModelAndView mv = new ModelAndView();
	        mv.setViewName("customers");
	        mv.addObject("customerList", customerService.getCustomers());
	        mv.addObject("title", "Customer List");
	        return mv;
	    }
	
	 //Add new customer- Post
	   @PostMapping(value = "/customer/add", consumes = "application/x-www-form-urlencoded")
	    @ResponseStatus(value = HttpStatus.OK)
	    void addCustomer(Customer customer, HttpServletResponse httpResponse) throws Exception {
	        customerService.addCustomer(customer);
	        httpResponse.sendRedirect("/customers");
	    }
	   
	   
	   // get and edit using customerid - GET
	    @GetMapping(value = "/customer/edit/{customerId}")
	    ModelAndView getCustomer(@PathVariable("customerId") int customerId) throws Exception {
	        ModelAndView mv = new ModelAndView();
	        mv.setViewName("editCustomer");
	        mv.addObject("customer", customerService.getCustomer(customerId));
	        return mv;
	    }
	    
	    @PostMapping(value = "/customer/edit/{customerId}", consumes = "application/x-www-form-urlencoded")
	    @ResponseStatus(value = HttpStatus.OK)
	    void updateCustomer(Customer customer, HttpServletResponse httpResponse) throws Exception {
	        customerService.updateCustomer(customer);
	        httpResponse.sendRedirect("/customers");
	    }
	    
	 // delete a customer instance- GET
	    @GetMapping(value = "/customer/delete/{customerId}")
	    @ResponseStatus(value = HttpStatus.OK)
	    void deleteJob(@PathVariable("customerId") int customerID, HttpServletResponse httpResponse) throws Exception {
	        customerService.deleteCustomer(customerID);
	        httpResponse.sendRedirect("/customers");
	    }
}
