package com.springboot.mvc.Model;

public class Cruise {
		private int cruiseCode;
	    private String cruiseName;
	    private String visitingPlaces;
	    private Double price;
	    private int duration;
	    
	    
	    
	    
		public Cruise() {
		
		}




		public Cruise(int cruiseCode, String cruiseName, String visitingPlaces, Double price, int duration) {
			super();
			this.cruiseCode = cruiseCode;
			this.cruiseName = cruiseName;
			this.visitingPlaces = visitingPlaces;
			this.price = price;
			this.duration = duration;
		}




		public int getCruiseCode() {
			return cruiseCode;
		}




		public void setCruiseCode(int cruiseCode) {
			this.cruiseCode = cruiseCode;
		}




		public String getCruiseName() {
			return cruiseName;
		}




		public void setCruiseName(String cruiseName) {
			this.cruiseName = cruiseName;
		}




		public String getVisitingPlaces() {
			return visitingPlaces;
		}




		public void setVisitingPlaces(String visitingPlaces) {
			this.visitingPlaces = visitingPlaces;
		}




		public Double getPrice() {
			return price;
		}




		public void setPrice(Double price) {
			this.price = price;
		}




		public int getDuration() {
			return duration;
		}




		public void setDuration(int duration) {
			this.duration = duration;
		}
	    
	    
	    
	    
	    
}
