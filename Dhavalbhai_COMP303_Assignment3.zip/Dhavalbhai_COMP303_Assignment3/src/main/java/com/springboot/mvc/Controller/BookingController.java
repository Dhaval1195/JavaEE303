package com.springboot.mvc.Controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.mvc.Model.Booking;
import com.springboot.mvc.Services.BookingService;


/* Used template and refer to code from
read://https_www.baeldung.com/?url=https%3A%2F%2Fwww.baeldung.com%2Fspring-boot-crud-thymeleaf
*/
@RestController
public class BookingController {

	@Autowired
    BookingService bookingService;
	
	
	 @GetMapping(value = "/bookings")
	    ModelAndView getCruises() throws Exception {
	        ModelAndView mv = new ModelAndView();
	        mv.setViewName("bookings");
	        mv.addObject("bookingList", bookingService.getBookings());
	        mv.addObject("title", "Booking List"); 
	        return mv;
	    }
	
	 
	   @PostMapping(value = "/booking/add", consumes = "application/x-www-form-urlencoded")
	    @ResponseStatus(value = HttpStatus.OK)
	    void addBooking(Booking booking, HttpServletResponse httpResponse) throws Exception {
	        bookingService.addBooking(booking);
	        httpResponse.sendRedirect("/bookings");
	    }
	   
	   
	   // GET - find by CruiseCode
	    @GetMapping(value = "/booking/edit/{bookingId}")
	    ModelAndView getBooking(@PathVariable("bookingId") int bookingId) throws Exception {
	        ModelAndView mv = new ModelAndView();
	        mv.setViewName("editBooking");
	        mv.addObject("booking", bookingService.getBooking(bookingId));
	        
	        return mv;
	    }
	    
	    @PostMapping(value = "/booking/edit/{bookingId}", consumes = "application/x-www-form-urlencoded")
	    @ResponseStatus(value = HttpStatus.OK)
	    void updateBooking(Booking booking, HttpServletResponse httpResponse) throws Exception {
	        bookingService.updateBooking(booking);
	        httpResponse.sendRedirect("/bookings");
	    }
	    
	 // DELETE - delete a booking 
	    @GetMapping(value = "/booking/delete/{bookingId}")
	    @ResponseStatus(value = HttpStatus.OK)
	    void deleteBooking(@PathVariable("bookingId") int bookingId, HttpServletResponse httpResponse) throws Exception {
	        bookingService.deleteBooking(bookingId);
	        
	        // redirect to booking list
	        httpResponse.sendRedirect("/bookings");
	    }
}
