package com.springboot.mvc.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/* Used template and refer to code from
read://https_www.baeldung.com/?url=https%3A%2F%2Fwww.baeldung.com%2Fspring-boot-crud-thymeleaf
*/

@Controller
public class HomeController {
    // root
    @RequestMapping("/")
    public String home() {
        return "index";
    }
    
    @RequestMapping("/addCustomer")
    public String addCustomer() {
        return "addCustomer";
    }
    
    
    @RequestMapping("/addCruise")
    public String addCruise() {
        return "addCruise";
    }
}
