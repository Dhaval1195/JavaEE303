package com.dhaval.mvc;

/*
Name : Dhavalbhai Patel
Student ID: 301240426
Date:06-10-2022   */
public class Registration {

	private int QuantityShirts;
	private int QuantityShorts;
	public int getQuantityShirts() {
		return QuantityShirts;
	}
	public void setQuantityShirts(int quantityShirts) {
		QuantityShirts = quantityShirts;
	}
	public int getQuantityShorts() {
		return QuantityShorts;
	}
	public void setQuantityShorts(int quantityShorts) {
		QuantityShorts = quantityShorts;
	}
	
	//to calculate total amount of quantity of shirts and shorts
	public int calculatePrice(int QuantityShirts, int QuantityShorts)
    {
        return QuantityShirts*38 + QuantityShorts*32;
    }
	

}
