package com.dhaval.mvc;
/*
Name : Dhavalbhai Patel
Student ID: 301240426
Date:06-10-2022   */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegistrationController {
	
	 //mapping with index.jsp
	@RequestMapping("/show-details")  
	   public ModelAndView register(HttpServletRequest request,HttpServletResponse response) {
		
		//getting all parameter sent from index.php
		String childFname = request.getParameter("DfirstName");
		String childLname = request.getParameter("DlastName");
		String cBirthmonth = request.getParameter("DBirthmonth");
		String cBirthday = request.getParameter("DBirthday");
		String cBirthyear = request.getParameter("DBirthyear");
		String parentfirstName = request.getParameter("DparentfirstName");
		String phoneNumber = request.getParameter("DparentphoneNumber");
		String phoneAreaNumber = request.getParameter("DareaCode");
		
		//to combine areacode and phone number 
		String CompleteNumber=phoneAreaNumber+phoneNumber;

		String Email = request.getParameter("DEmail");
		String phyfirstName = request.getParameter("DphyfirstName");
		String phylastName = request.getParameter("DphylastName");
		String phyphoneNumber = request.getParameter("DphyphoneNumber");
		String phyphoneAreaNumber = request.getParameter("DphareaCode");
		String PhCompeletNumber=phyphoneAreaNumber+phyphoneNumber;

		//as we need to perform some operation so this block will store data in integer variable
		int QuantityShirts = Integer.parseInt(request.getParameter("DQuantityShirts"));
		int QuantityShorts = Integer.parseInt(request.getParameter("DQuantityShorts"));
		
	    
		//passing data from controller to view with parameters
	    			ModelAndView mview = new ModelAndView("show-details");
	    			mview.addObject("dchildFname", childFname);
	    			mview.addObject("dchildLname", childLname);
	    			mview.addObject("dBirthmonth", cBirthmonth);
	    			mview.addObject("dBirthday", cBirthday);
	    			mview.addObject("dBirthyear", cBirthyear);
	    			mview.addObject("dEmail", Email);
	    			mview.addObject("dphoneNumber", CompleteNumber);
	    			mview.addObject("dphyfirstName", phyfirstName);
	    			mview.addObject("dphylastName", phylastName);
	    			mview.addObject("dphyphoneNumber", PhCompeletNumber);
	    			mview.addObject("dQuantityShirts", QuantityShirts);
	    			mview.addObject("dQuantityShorts", QuantityShorts);
	    			//to perform operation on quantity of shirts and shorts
	    			Registration PriceCheckObj=new Registration();
					//calling method to perform calculation
					 int priceTotal = PriceCheckObj.calculatePrice(QuantityShirts, QuantityShorts);
					 
					 mview.addObject("dpriceTotal", priceTotal);
	    			mview.addObject("dparentfirstName", parentfirstName);
	    			
	    			
	    			return mview;
	    			
	    	
	     
	}

}
