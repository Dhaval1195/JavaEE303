package com.springboot.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DhavalbhaiComp303Assignment2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
