package com.springboot.mvc;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;


public interface SportsRepository extends JpaRepository<Sports, Integer>{
    public List<Sports> findById(int sportId);

}
