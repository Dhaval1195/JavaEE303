package com.springboot.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.springboot.mvc")
public class DhavalbhaiComp303Assignment2Application {

	public static void main(String[] args) {
		SpringApplication.run(DhavalbhaiComp303Assignment2Application.class, args);
	}

}
