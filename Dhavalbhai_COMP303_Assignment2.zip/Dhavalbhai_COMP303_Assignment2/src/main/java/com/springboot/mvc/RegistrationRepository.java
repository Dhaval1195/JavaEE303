package com.springboot.mvc;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RegistrationRepository extends JpaRepository<Registration, Integer> {
    public List<Registration> findByStudentId(int studentId);

}
